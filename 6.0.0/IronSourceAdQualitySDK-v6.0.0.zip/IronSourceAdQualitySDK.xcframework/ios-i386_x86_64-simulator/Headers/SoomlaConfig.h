//
//  SoomlaConfig.h
//  SoomlaTraceback
//
//  Created by Boris Spektor on 25/10/2018.
//  Copyright © 2018 SOOMLA. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    TB_LOG_LEVEL_NONE       = 0,
    TB_LOG_LEVEL_ERROR      = 1,
    TB_LOG_LEVEL_WARNING    = 2,
    TB_LOG_LEVEL_INFO       = 3,
    TB_LOG_LEVEL_DEBUG      = 4,
    TB_LOG_LEVEL_VERBOSE    = 5
} TracebackLogLevel;

typedef enum {
    TB_SDK_WAS_SHUTDOWN                             = 0,
    TB_ILLEGAL_USER_ID                              = 1,
    TB_ILLEGAL_APPKEY                               = 2,
    TB_EXCEPTION_ON_INIT                            = 3,
    TB_NO_NETWORK_CONNECTION                        = 4,
    TB_CONFIG_LOAD_TIMEOUT                          = 5,
    TB_CONNECTOR_LOAD_TIMEOUT                       = 6,
    TB_AD_NETWORK_VERSION_NOT_SUPPORTED_YET         = 7,
    TB_AD_NETWORK_SDK_REQUIRES_NEWER_SOOMLA_SDK     = 8
} SoomlaSDKInitError;


@protocol SoomlaSdkInitDelegate <NSObject>
- (void)iSAdQualitySdkOnSuccess;
- (void)iSAdQualitySdkOnFailed:(SoomlaSDKInitError)error withMessage:(NSString *)message;
@end

@interface SoomlaConfig : NSObject

@property (nonatomic) NSString *userId;
@property (nonatomic) BOOL testMode;
@property (nonatomic) TracebackLogLevel logLevel;
@property (nonatomic, weak) id<SoomlaSdkInitDelegate> soomlaSdkInitDelegate;

+ (SoomlaConfig*)config;

@end
